# Changelog

## 27. 2. 2021.

Font points are rounded to integral values. Previously, due to the author's oversight when generating the font, this was not the case.

## [0.1.1] - 19.  2. 2021.

Only minor correction of quotation marks and commas. 

## [0.1] - 20. 9. 2020.

Initial release.

Completely covered Unicode blocks: Basic Latin, Latin-1 Supplement, Latin Extended-A and Cyrillic. Latin Extended-B is partialy covered and there is also a bunch of some other  glyphs. Serbian and English characters have five variation each.
