# Tihana

Version 0.1
By Веско Радић <radic.vesko@gmail.com>

About
-----

Tihana is a font intended primarily for comics. It is a hobby project, so I accept responsibility for all possible mistakes in advance.

![tihana example](https://github.com/VeskoRadic/tihana-font/blob/master/lorem_ipsum.png)

Licence
-------

Tihana is released under the [OFL](https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL) licence.
